import show from './show'

export default {
  show
}
